import WidgetKit
import SwiftUI

let appGroupID = "group.com.diy.ledger"

// MARK: - Data Models
struct LedgerRecord: Codable {
    let id: String
    let type: String
    let category: String?
    let amount: Double
    let note: String?
    let time: Double
}
struct LedgerData: Codable {
    let records: [LedgerRecord]?
}

struct DadRecord: Codable {
    let id: String
    let type: String
    let amount: Double
    let note: String?
    let time: Double
}
struct DadData: Codable {
    let records: [DadRecord]?
    let title: String?
}

func loadJSON<T: Codable>(_ fileName: String, as type: T.Type) -> T? {
    guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupID) else { return nil }
    let url = container.appendingPathComponent(fileName)
    guard let data = try? Data(contentsOf: url) else { return nil }
    return try? JSONDecoder().decode(T.self, from: data)
}

// MARK: - 日常记账 Widget
struct LedgerProvider: TimelineProvider {
    func placeholder(in context: Context) -> LedgerEntry {
        LedgerEntry(date: Date(), todayIn: 0, todayOut: 0, monthIn: 0, monthOut: 0)
    }
    func getSnapshot(in context: Context, completion: @escaping (LedgerEntry) -> ()) {
        completion(placeholder(in: context))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<LedgerEntry>) -> ()) {
        let data = loadJSON("ledger.json", as: LedgerData.self)
        let now = Date()
        var ti = 0.0, te = 0.0, mi = 0.0, me = 0.0
        if let records = data?.records {
            for r in records {
                let d = Date(timeIntervalSince1970: r.time / 1000)
                if Calendar.current.isDate(d, inSameDayAs: now) {
                    if r.type == "in" { ti += r.amount } else { te += r.amount }
                }
                if Calendar.current.isDate(d, equalTo: now, toGranularity: .month) {
                    if r.type == "in" { mi += r.amount } else { me += r.amount }
                }
            }
        }
        let entry = LedgerEntry(date: now, todayIn: ti, todayOut: te, monthIn: mi, monthOut: me)
        let next = Calendar.current.date(byAdding: .minute, value: 15, to: now) ?? now.addingTimeInterval(900)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct LedgerEntry: TimelineEntry {
    let date: Date
    let todayIn: Double
    let todayOut: Double
    let monthIn: Double
    let monthOut: Double
}

struct LedgerWidgetView: View {
    var entry: LedgerProvider.Entry
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 4) {
                Image(systemName: "wallet.pass.fill").foregroundColor(.orange).font(.system(size: 12))
                Text("日常记账").font(.system(size: 13, weight: .semibold))
                Spacer()
                Text(entry.date, format: .dateTime.month().day()).font(.system(size: 10)).foregroundColor(.secondary)
            }
            Spacer(minLength: 4)
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("今日收入").font(.system(size: 9)).foregroundColor(.secondary)
                    Text("¥\(Int(entry.todayIn))").font(.system(size: 15, weight: .heavy)).foregroundColor(.green)
                }
                Spacer()
                VStack(alignment: .leading, spacing: 2) {
                    Text("今日支出").font(.system(size: 9)).foregroundColor(.secondary)
                    Text("¥\(Int(entry.todayOut))").font(.system(size: 15, weight: .heavy)).foregroundColor(.red)
                }
                Spacer()
                VStack(alignment: .leading, spacing: 2) {
                    Text("今日结余").font(.system(size: 9)).foregroundColor(.secondary)
                    Text("¥\(Int(entry.todayIn - entry.todayOut))").font(.system(size: 15, weight: .heavy)).foregroundColor(.orange)
                }
            }
            Divider().padding(.vertical, 2)
            HStack {
                Spacer()
                Text("本月：收入¥\(Int(entry.monthIn))  结余¥\(Int(entry.monthIn - entry.monthOut))")
                    .font(.system(size: 9)).foregroundColor(.secondary)
                Spacer()
            }
        }
        .padding(14)
    }
}

struct LedgerWidget: Widget {
    let kind: String = "LedgerWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: LedgerProvider()) { entry in
            LedgerWidgetView(entry: entry)
        }
        .configurationDisplayName("日常记账")
        .description("显示今日和本月收支情况")
        .supportedFamilies([.systemMedium])
    }
}

// MARK: - 代收记账 Widget
struct DadProvider: TimelineProvider {
    func placeholder(in context: Context) -> DadEntry {
        DadEntry(date: Date(), balance: 0, totalIn: 0, totalOut: 0, title: "老爸代管余额")
    }
    func getSnapshot(in context: Context, completion: @escaping (DadEntry) -> ()) {
        completion(placeholder(in: context))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<DadEntry>) -> ()) {
        let data = loadJSON("dad.json", as: DadData.self)
        var inc = 0.0, out = 0.0
        if let records = data?.records {
            for r in records {
                if r.type == "in" { inc += r.amount }
                else if r.type == "out" { out += r.amount }
            }
        }
        let entry = DadEntry(date: Date(), balance: inc - out, totalIn: inc, totalOut: out, title: data?.title ?? "代管余额")
        let next = Calendar.current.date(byAdding: .minute, value: 15, to: Date()) ?? Date().addingTimeInterval(900)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct DadEntry: TimelineEntry {
    let date: Date
    let balance: Double
    let totalIn: Double
    let totalOut: Double
    let title: String
}

struct DadWidgetView: View {
    var entry: DadProvider.Entry
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 4) {
                Image(systemName: "person.crop.circle.fill").foregroundColor(.blue).font(.system(size: 12))
                Text(entry.title).font(.system(size: 13, weight: .semibold)).lineLimit(1)
                Spacer()
            }
            Spacer(minLength: 4)
            Text("¥\(String(format: "%.2f", entry.balance))")
                .font(.system(size: 26, weight: .heavy))
                .foregroundColor(entry.balance >= 0 ? .primary : .red)
            Spacer(minLength: 4)
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("累计代收").font(.system(size: 9)).foregroundColor(.secondary)
                    Text("¥\(Int(entry.totalIn))").font(.system(size: 12, weight: .semibold)).foregroundColor(.green)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("累计取回").font(.system(size: 9)).foregroundColor(.secondary)
                    Text("¥\(Int(entry.totalOut))").font(.system(size: 12, weight: .semibold)).foregroundColor(.red)
                }
            }
        }
        .padding(14)
    }
}

struct DadWidget: Widget {
    let kind: String = "DadWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: DadProvider()) { entry in
            DadWidgetView(entry: entry)
        }
        .configurationDisplayName("代收记账")
        .description("显示代管余额和累计代收取回")
        .supportedFamilies([.systemMedium])
    }
}

@main
struct LedgerWidgets: WidgetBundle {
    var body: some Widget {
        LedgerWidget()
        DadWidget()
    }
}
