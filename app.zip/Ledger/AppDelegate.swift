import UIKit
import WidgetKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    var pendingURL: URL?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        let vc = ViewController()
        window?.rootViewController = vc
        window?.makeKeyAndVisible()

        if let url = pendingURL {
            vc.handleDeepLink(url)
            pendingURL = nil
        }
        return true
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.LaunchOptionsKey : Any] = [:]) -> Bool {
        if let vc = window?.rootViewController as? ViewController {
            vc.handleDeepLink(url)
        } else {
            pendingURL = url
        }
        return true
    }
}
